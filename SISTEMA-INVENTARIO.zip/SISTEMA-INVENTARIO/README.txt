Dentro de las actualizaciones se encuentra
1)la funcion de eliminar producto
2)listar productos agotados